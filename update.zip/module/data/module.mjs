import Ship from "./actor/ship.mjs";
import Character from "./actor/character.mjs"

export const actor = {
    "starlink.Ship": Ship,
    "starlink.Character": Character
};

export const item = {}