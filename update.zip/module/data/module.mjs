import Ship from "./actor/ship.mjs";
import Character from "./actor/character.mjs"

export const actor = {
    "ship": Ship,
    "character": Character
};

export const item = {}